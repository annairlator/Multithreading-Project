1. Open a terminal
2. type 'make'and hit enter
3. Run program with the command line arguments of mode and number of threads
4.* example: ./Project2.0.exe 1 200